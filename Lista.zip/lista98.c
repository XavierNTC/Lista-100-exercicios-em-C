#include <stdio.h>

#define LINHAS_MATRIZ1 4
#define COLUNAS_MATRIZ1 3
#define LINHAS_MATRIZ2 3
#define COLUNAS_MATRIZ2 2


void produtoMatrizes(int matriz1[][COLUNAS_MATRIZ1], int matriz2[][COLUNAS_MATRIZ2], int resultado[][COLUNAS_MATRIZ2]) {
    for (int i = 0; i < LINHAS_MATRIZ1; ++i) {
        for (int j = 0; j < COLUNAS_MATRIZ2; ++j) {
            resultado[i][j] = 0;

            for (int k = 0; k < LINHAS_MATRIZ2; ++k) {
                resultado[i][j] += matriz1[i][k] * matriz2[k][j];
            }
        }
    }
}


void exibirMatriz(int matriz[][COLUNAS_MATRIZ2], int linhas, int colunas) {
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    int matriz1[LINHAS_MATRIZ1][COLUNAS_MATRIZ1];
    int matriz2[LINHAS_MATRIZ2][COLUNAS_MATRIZ2];
    int resultado[LINHAS_MATRIZ1][COLUNAS_MATRIZ2];

    
    printf("Digite os valores para preencher a primeira matriz 4x3:\n");
    for (int i = 0; i < LINHAS_MATRIZ1; ++i) {
        for (int j = 0; j < COLUNAS_MATRIZ1; ++j) {
            printf("Matriz1[%d][%d]: ", i, j);
            scanf("%d", &matriz1[i][j]);
        }
    }

    
    printf("\nDigite os valores para preencher a segunda matriz 3x2:\n");
    for (int i = 0; i < LINHAS_MATRIZ2; ++i) {
        for (int j = 0; j < COLUNAS_MATRIZ2; ++j) {
            printf("Matriz2[%d][%d]: ", i, j);
            scanf("%d", &matriz2[i][j]);
        }
    }

    
    produtoMatrizes(matriz1, matriz2, resultado);
    printf("\nMatriz Resultante (Produto das Matrizes):\n");
    exibirMatriz(resultado, LINHAS_MATRIZ1, COLUNAS_MATRIZ2);

    return 0;
}
