#include <stdio.h>

int main() {
    // Declare as variáveis para as notas dos exames
    float notaI, notaII, notaIII, notaIV, notaV;

    // Solicite que o usuário insira as notas dos exames
    printf("Digite as notas dos exames (I II III IV V): ");
    scanf("%f %f %f %f %f", &notaI, &notaII, &notaIII, &notaIV, &notaV);

    // Calcule a média das notas
    float media = (notaI + notaII + notaIII + notaIV + notaV) / 5;

    // Determine a classificação do aluno e exiba-a
    if (media >= 70) {
        printf("Classificação: A - Passou em todos os exames.\n");
    } else if (notaI >= 70 && notaII >= 70 && notaIV >= 70 && (notaIII < 70 || notaV < 70)) {
        printf("Classificação: B - Passou em I, II e IV, mas não em III ou V.\n");
    } else if ((notaI >= 70 && notaII >= 70) && (notaIII >= 70 || notaIV >= 70) && notaV < 70) {
        printf("Classificação: C - Passou em I e II, III ou IV, mas não em V.\n");
    } else {
        printf("Classificação: Reprovado - Outras situações.\n");
    }

    return 0;
}