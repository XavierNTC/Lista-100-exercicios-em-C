#include <stdio.h>

int main() {
    int N;
    printf("Digite o valor de N para a série de Fibonacci: ");
    scanf("%d", &N);

    int a = 0, b = 1, temp;
    printf("Série de Fibonacci até o %d-ésimo termo:\n", N);
    for (int i = 0; i < N; i++) {
        printf("%d ", a);
        temp = a;
        a = b;
        b = temp + b;
    }

    return 0;
}