#include <stdio.h>

int main() {
    // Declare as variáveis para a renda mensal, valor total do empréstimo e número de prestações
    float rendaMensal, valorEmprestimo;
    int numPrestacoes;

    // Solicite que o usuário insira os valores
    printf("Digite a renda mensal do solicitante: R$ ");
    scanf("%f", &rendaMensal);

    printf("Digite o valor total do empréstimo solicitado: R$ ");
    scanf("%f", &valorEmprestimo);

    printf("Digite o número de prestações desejadas: ");
    scanf("%d", &numPrestacoes);

    // Verifique se o empréstimo pode ser concedido
    if (valorEmprestimo <= 10 * rendaMensal && (valorEmprestimo / numPrestacoes) <= (0.3 * rendaMensal)) {
        printf("Empréstimo concedido.\n");
    } else {
        printf("Empréstimo não concedido.\n");
    }

    return 0;
}