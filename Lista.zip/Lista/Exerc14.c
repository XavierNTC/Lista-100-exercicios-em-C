#include <stdio.h>
#include <math.h>

int main() {
    // Declare as variáveis para armazenar as informações
    float distancia, velocidade, aceleracao;

    // Solicite que o usuário insira as informações
    printf("Distancia entre semáforos (metros): ");
    scanf("%f", &distancia);

    printf("Velocidade permitida (m/s): ");
    scanf("%f", &velocidade);

    printf("Aceleração típica dos carros (m/s^2): ");
    scanf("%f", &aceleracao);

    // Calcule o tempo necessário para percorrer a distância
    float tempo = sqrt(2 * distancia / aceleracao);

    // Determine quando o próximo semáforo deve abrir (por exemplo, 3 segundos antes da chegada)
    float tempoAbertura = tempo - 3;

    // Exiba o resultado
    printf("O próximo semáforo deve abrir %.2f segundos depois.\n", tempoAbertura);

    return 0;
}