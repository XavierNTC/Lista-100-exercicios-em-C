#include <stdio.h>

int main() {
    // Declaração das variáveis
    float base, altura, area, perimetro;

    // Solicitação dos valores de base e altura
    printf("Digite o valor da base do retângulo: ");
    scanf("%f", &base);
    
    printf("Digite o valor da altura do retângulo: ");
    scanf("%f", &altura);

    // Cálculo da área e do perímetro
    area = base * altura;
    perimetro = 2 * (base + altura);

    // Exibição dos resultados
    printf("Área do retângulo: %.2f\n", area);
    printf("Perímetro do retângulo: %.2f\n", perimetro);

    return 0;
}