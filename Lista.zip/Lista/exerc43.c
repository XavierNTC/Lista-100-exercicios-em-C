#include <stdio.h>

int main() {
    // Imprima todos os números pares do intervalo fechado de 1 a 100
    for (int i = 2; i <= 100; i += 2) {
        printf("%d ", i);
    }
    printf("\n");

    return 0;
}