#include <stdio.h>

int main() {
    int array[100];
    int tamanho = 0;

    printf("Digite até 100 números (digite -1 para encerrar):\n");

    int numero;
    scanf("%d", &numero);

    while (numero != -1 && tamanho < 100) {
        array[tamanho] = numero;
        tamanho++;
        scanf("%d", &numero);
    }

    printf("Array carregado:\n");
    for (int i = 0; i < tamanho; i++) {
        printf("%d ", array[i]);
    }
    printf("\n");

    return 0;
}
