#include <stdio.h>

int main() {
    int array[20];

    printf("Digite 20 números:\n");
    for (int i = 0; i < 20; i++) {
        scanf("%d", &array[i]);
    }

    int menor = array[0], maior = array[0];
    int posicaoMenor = 0, posicaoMaior = 0;

    for (int i = 1; i < 20; i++) {
        if (array[i] < menor) {
            menor = array[i];
            posicaoMenor = i;
        }
        if (array[i] > maior) {
            maior = array[i];
            posicaoMaior = i;
        }
    }

    printf("Menor valor: %d (Posição: %d)\n", menor, posicaoMenor);
    printf("Maior valor: %d (Posição: %d)\n", maior, posicaoMaior);

    return 0;
}
