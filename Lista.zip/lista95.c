#include <stdio.h>

#define TAMANHO 6


void linearizarMatriz(int matriz[][TAMANHO], int vetor[]) {
    int indice = 0;
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            vetor[indice++] = matriz[i][j];
        }
    }
}


void exibirVetor(int vetor[]) {
    for (int i = 0; i < TAMANHO * TAMANHO; ++i) {
        printf("%d\t", vetor[i]);
    }
    printf("\n");
}

int main() {
    int matriz[TAMANHO][TAMANHO];
    int vetor[TAMANHO * TAMANHO];

    
    printf("Digite os valores para preencher a matriz 6x6:\n");
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    
    linearizarMatriz(matriz, vetor);

    
    printf("\nConteúdo do vetor linearizado:\n");
    exibirVetor(vetor);

    return 0;
}
