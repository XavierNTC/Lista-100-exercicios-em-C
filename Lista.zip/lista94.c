#include <stdio.h>

#define TAMANHO 6


void multiplicarMatriz(int matriz[][TAMANHO], int valor) {
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            matriz[i][j] *= valor;
        }
    }
}


void exibirMatriz(int matriz[][TAMANHO]) {
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int matriz[TAMANHO][TAMANHO];
    int valor;

  
    printf("Digite os valores para preencher a matriz 6x6:\n");
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

  
    printf("\nDigite um valor inteiro para multiplicar a matriz: ");
    scanf("%d", &valor);

    
    multiplicarMatriz(matriz, valor);

   
    printf("\nMatriz resultante:\n");
    exibirMatriz(matriz);

    return 0;
}
