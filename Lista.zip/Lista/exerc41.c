#include <stdio.h>

int main() {
    // Imprima todos os números inteiros do intervalo fechado de 1 a 100
    for (int i = 1; i <= 100; i++) {
        printf("%d ", i);
    }
    printf("\n");

    return 0;
}