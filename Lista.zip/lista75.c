#include <stdio.h>
void trocar(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}

void bubbleSort(int array[], int tamanho) {
    for (int i = 0; i < tamanho - 1; ++i) {
        for (int j = 0; j < tamanho - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                trocar(&array[j], &array[j + 1]);
            }
        }
    }
}

void exibirArray(int array[], int tamanho) {
    printf("Array ordenado: ");
    for (int i = 0; i < tamanho; ++i) {
        printf("%d ", array[i]);
    }
    printf("\n");
}

int main() {
    const int tamanhoArray = 15;
    int array[tamanhoArray];

    printf("Digite os 15 elementos do array:\n");
    for (int i = 0; i < tamanhoArray; ++i) {
        scanf("%d", &array[i]);
    }

    bubbleSort(array, tamanhoArray);

    exibirArray(array, tamanhoArray);

    return 0;
}
    
