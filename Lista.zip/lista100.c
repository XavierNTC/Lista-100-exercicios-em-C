#include <stdio.h>

#define MAX 10


int verificaQuadradoLatino(int matriz[MAX][MAX], int N) {
   
    for (int i = 0; i < N; ++i) {
        int numeros[N + 1] = {0}; 

        for (int j = 0; j < N; ++j) {
            int valor = matriz[i][j];

            if (valor < 1 || valor > N || numeros[valor] != 0) {
                return 0; 
            }

            numeros[valor] = 1;
        }
    }

   
    for (int j = 0; j < N; ++j) {
        int numeros[N + 1] = {0};

        for (int i = 0; i < N; ++i) {
            int valor = matriz[i][j];

            if (valor < 1 || valor > N || numeros[valor] != 0) {
                return 0; 
            }

            numeros[valor] = 1;
        }
    }

    return 1; 
}


void exibirMatriz(int matriz[MAX][MAX], int linhas, int colunas) {
    for (int i = 0; i < linhas; ++i) {
        for (int j = 0; j < colunas; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
}

int main() {
    int N;
    int matriz[MAX][MAX];

   
    printf("Informe a ordem N da matriz (até %d): ", MAX);
    scanf("%d", &N);

   
    printf("Digite os valores para preencher a matriz %dx%d:\n", N, N);
    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < N; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    
    printf("\nMatriz Informada:\n");
    exibirMatriz(matriz, N, N);

   
    if (verificaQuadradoLatino(matriz, N)) {
        printf("\nA matriz é um Quadrado Latino de ordem %d.\n", N);
    } else {
        printf("\nA matriz NÃO é um Quadrado Latino de ordem %d.\n", N);
    }

    return 0;
}
