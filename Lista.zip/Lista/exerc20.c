#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar o valor da mercadoria, entrada e prestações
    float valorMercadoria, entrada, prestacao1, prestacao2;

    // Solicite que o usuário insira o valor da mercadoria
    printf("Digite o valor da mercadoria: R$ ");
    scanf("%f", &valorMercadoria);

    // Verifique se o valor da mercadoria é válido
    if (valorMercadoria >= 0) {
        // Calcule a entrada e as duas prestações
        entrada = valorMercadoria / 3;
        prestacao1 = entrada;
        prestacao2 = entrada;

        // Ajuste as prestações se necessário para satisfazer a condição de entrada maior ou igual às prestações
        if (valorMercadoria % 3 != 0) {
            entrada += valorMercadoria % 3;
            prestacao1 = entrada;
        }

        // Exiba os resultados
        printf("Valor da entrada: R$ %.2f\n", entrada);
        printf("Valor da primeira prestação: R$ %.2f\n", prestacao1);
        printf("Valor da segunda prestação: R$ %.2f\n", prestacao2);
    } else {
        printf("Por favor, digite um valor de mercadoria válido.\n");
    }

    return 0;
 }