#include <stdio.h>

int main() {
    int array[20] = {0};

    for (int i = 0; i < 20; i++) {
        printf("Posição %d: %d\n", i, array[i]);
    }

    return 0;
}
