#include <stdio.h>
#include <string.h>
#include <ctype.h>

int saoIguais(const char *str1, const char *str2) {
    while (*str1 != '\0' && *str2 != '\0') {
        
        if (tolower(*str1) != tolower(*str2)) {
            return 0; 
        }

        str1++;
        str2++;
    }

    return (*str1 == '\0' && *str2 == '\0');
}

int main() {
    char str1[100];
    char str2[100];

    printf("Digite a primeira string: ");
    fgets(str1, sizeof(str1), stdin);

    str1[strcspn(str1, "\n")] = '\0';

    printf("Digite a segunda string: ");
    fgets(str2, sizeof(str2), stdin);

    str2[strcspn(str2, "\n")] = '\0';

    if (saoIguais(str1, str2)) {
        printf("As strings são iguais.\n");
    } else {
        printf("As strings não são iguais.\n");
    }

    return 0;
}
