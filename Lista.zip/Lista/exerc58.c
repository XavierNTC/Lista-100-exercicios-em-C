#include <stdio.h>

// Função para calcular o valor aproximado de π usando a série fornecida
double calcularPi(int N) {
    double S = 1.0;
    double termo = 1.0;

    for (int i = 1; i <= N; i++) {
        termo *= (2 * i - 1);
        termo /= (2 * i);
        if (i % 2 == 1) {
            S += termo;
        } else {
            S -= termo;
        }
    }

    return S * 4;
}

int main() {
    int N;

    printf("Digite o valor de N: ");
    scanf("%d", &N);

    double resultadoPi = calcularPi(N);

    printf("O valor aproximado de π usando os primeiros %d termos é: %.15f\n", N, resultadoPi);

    return 0;
}
