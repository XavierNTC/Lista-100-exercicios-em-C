#include <stdio.h>

int main() {
    // Declare a variável para armazenar a idade em dias
    int idadeDias;

    // Solicite que o usuário insira a idade em dias
    printf("Digite a idade em dias: ");
    scanf("%d", &idadeDias);

    // Calcule a idade em anos, meses e dias
    int anos = idadeDias / 365;
    int meses = (idadeDias % 365) / 30;
    int dias = (idadeDias % 365) % 30;

    // Exiba os resultados
    printf("Idade: %d anos, %d meses, %d dias\n", anos, meses, dias);

    return 0;
}