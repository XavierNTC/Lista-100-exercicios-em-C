#include <stdio.h>


void exibirVetor(int vetor[], int tamanho) {
    printf("Vetor: ");
    for (int i = 0; i < tamanho; ++i) {
        printf("%d ", vetor[i]);
    }
    printf("\n");
}

void inserirNoFinal(int vetor[], int *tamanho, int elemento) {
    if (*tamanho < 30) {
        vetor[*tamanho] = elemento;
        (*tamanho)++;
        printf("Elemento %d inserido no final do vetor.\n", elemento);
    } else {
        printf("Erro: O vetor está cheio.\n");
    }
}

void inserirNaPosicao(int vetor[], int *tamanho, int posicao, int elemento) {
    if (*tamanho < 30 && posicao >= 0 && posicao <= *tamanho) {
        for (int i = *tamanho; i > posicao; --i) {
            vetor[i] = vetor[i - 1];
        }

        vetor[posicao] = elemento;
        (*tamanho)++;
        printf("Elemento %d inserido na posição %d do vetor.\n", elemento, posicao);
    } else {
        printf("Erro: Posição inválida ou vetor cheio.\n");
    }
}

void removerDaPosicao(int vetor[], int *tamanho, int posicao) {
    if (*tamanho > 0 && posicao >= 0 && posicao < *tamanho) {
        for (int i = posicao; i < *tamanho - 1; ++i) {
            vetor[i] = vetor[i + 1];
        }

        (*tamanho)--;
        printf("Elemento removido da posição %d do vetor.\n", posicao);
    } else {
        printf("Erro: Posição inválida ou vetor vazio.\n");
    }
}

void removerElemento(int vetor[], int *tamanho, int elemento) {
    int i, j;
    for (i = 0, j = 0; i < *tamanho; ++i) {
        if (vetor[i] != elemento) {
            vetor[j++] = vetor[i];
        }
    }

    *tamanho = j;
    printf("Elementos iguais a %d removidos do vetor.\n", elemento);
}

void removerDuplicatas(int vetor[], int *tamanho) {
    int i, j, k;

    for (i = 0; i < *tamanho; ++i) {
        for (j = i + 1; j < *tamanho;) {
            if (vetor[j] == vetor[i]) {
                for (k = j; k < *tamanho - 1; ++k) {
                    vetor[k] = vetor[k + 1];
                }
                (*tamanho)--;
            } else {
                ++j;
            }
        }
    }

    printf("Duplicatas removidas do vetor.\n");
}

int main() {
    int vetor[30];
    int tamanho = 0;
    int opcao, elemento, posicao;

    do {
        printf("\nEscolha uma opção:\n");
        printf("1. Inserir elemento no final\n");
        printf("2. Inserir elemento em uma posição\n");
        printf("3. Remover elemento de uma posição\n");
        printf("4. Remover todos elementos iguais a um valor\n");
        printf("5. Gerar novo array sem duplicidades\n");
        printf("0. Sair\n");

        scanf("%d", &opcao);

        switch (opcao) {
            case 1:
                printf("Digite o elemento a ser inserido no final: ");
                scanf("%d", &elemento);
                inserirNoFinal(vetor, &tamanho, elemento);
                break;

            case 2:
                printf("Digite a posição para inserir o elemento: ");
                scanf("%d", &posicao);
                printf("Digite o elemento a ser inserido: ");
                scanf("%d", &elemento);
                inserirNaPosicao(vetor, &tamanho, posicao, elemento);
                break;

            case 3:
                printf("Digite a posição do elemento a ser removido: ");
                scanf("%d", &posicao);
                removerDaPosicao(vetor, &tamanho, posicao);
                break;

            case 4:
                printf("Digite o valor do elemento a ser removido: ");
                scanf("%d", &elemento);
                removerElemento(vetor, &tamanho, elemento);
                break;

            case 5:
                removerDuplicatas(vetor, &tamanho);
                break;

            case 0:
                printf("Programa encerrado.\n");
                break;

            default:
                printf("Opção inválida. Tente novamente.\n");
                break;
        }

        exibirVetor(vetor, tamanho);

    } while (opcao != 0);

    return 0;
}
