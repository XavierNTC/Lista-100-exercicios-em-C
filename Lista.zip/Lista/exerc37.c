#include <stdio.h>

int main() {
    // Declare as variáveis para o tipo de pulverização, área e custo
    int tipoPulverizacao;
    float area, custo;

    // Solicite que o usuário insira o tipo de pulverização e a área
    printf("Digite o tipo de pulverização (1 a 4): ");
    scanf("%d", &tipoPulverizacao);

    printf("Digite a área a ser pulverizada (em acres): ");
    scanf("%f", &area);

    // Calcule o custo da pulverização
    switch (tipoPulverizacao) {
        case 1:
            custo = 50.0 * area;
            break;
        case 2:
            custo = 100.0 * area;
            break;
        case 3:
            custo = 150.0 * area;
            break;
        case 4:
            custo = 250.0 * area;
            break;
        default:
            printf("Tipo de pulverização inválido. Por favor, insira um número de 1 a 4.\n");
            return 1; // Código de erro
    }

    // Aplica desconto de 5% se a área for superior a 1000 acres
    if (area > 1000) {
        custo *= 0.95;
    }

    // Aplica desconto de 10% se o custo for maior que R$ 750,00
    if (custo > 750.0) {
        custo = 750.0 + (custo - 750.0) * 0.9;
    }

    // Exibe o valor a ser pago
    printf("O valor a ser pago pela pulverização é: R$ %.2f\n", custo);

    return 0;
}