#include <stdio.h>
#include <string.h>
#include <ctype.h>

void imprimirMaiorPalavra(const char *normalizada) {
    int tamanhoMaximo = 0;
    int tamanhoAtual = 0;
    const char *inicioMaior = normalizada;
    const char *inicioAtual = normalizada;

    while (*normalizada != '\0') {
        if (isspace(*normalizada)) {
           
            if (tamanhoAtual > tamanhoMaximo) {
                tamanhoMaximo = tamanhoAtual;
                inicioMaior = inicioAtual;
            }

            tamanhoAtual = 0;  
        } else {
            tamanhoAtual++;
            if (tamanhoAtual == 1) {
                inicioAtual = normalizada;  
            }
        }

        normalizada++;
    }

    if (tamanhoAtual > tamanhoMaximo) {
        tamanhoMaximo = tamanhoAtual;
        inicioMaior = inicioAtual;
    }

    printf("Maior palavra: ");
    for (int i = 0; i < tamanhoMaximo; ++i) {
        putchar(*(inicioMaior + i));
    }
    printf("\n");
}

int main() {
    char normalizada[100];

    printf("Digite uma string normalizada: ");
    fgets(normalizada, sizeof(normalizada), stdin);

    normalizada[strcspn(normalizada, "\n")] = '\0';

    imprimirMaiorPalavra(normalizada);

    return 0;
}
