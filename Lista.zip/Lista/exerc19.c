#include <stdio.h>

int main() {
    // Declare as variáveis para os coeficientes
    float a, b;

    // Solicite que o usuário insira os coeficientes
    printf("Digite o coeficiente a: ");
    scanf("%f", &a);

    printf("Digite o coeficiente b: ");
    scanf("%f", &b);

    // Verifique se a equação é do primeiro grau (a não pode ser zero)
    if (a != 0) {
        // Calcule a raiz da equação do primeiro grau
        float raiz = -b / a;

        // Exiba o resultado
        printf("A raiz da equação é x = %.2f\n", raiz);
    } else {
        printf("A equação não é do primeiro grau. O coeficiente 'a' não pode ser zero.\n");
    }

    return 0;
}