#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main() {
    // Declare as variáveis para armazenar o raio e a altura da lata
    float raio, altura;

    // Solicite que o usuário insira o raio e a altura da lata
    printf("Digite o raio da lata: ");
    scanf("%f", &raio);

    printf("Digite a altura da lata: ");
    scanf("%f", &altura);

    // Calcule o volume da lata usando a fórmula V = π * raio^2 * altura
    float volume = PI * pow(raio, 2) * altura;

    // Exiba o volume da lata
    printf("O volume da lata de óleo é: %.2f unidades cúbicas\n", volume);

    return 0;
}