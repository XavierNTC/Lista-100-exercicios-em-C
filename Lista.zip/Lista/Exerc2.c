#include <stdio.h>

int main() {
    // Defina o tamanho do lado do quadrado
    float lado;
    printf("Digite o tamanho do lado do quadrado: ");
    scanf("%f", &lado);

    // Calcule a área e o perímetro
    float area = lado * lado;
    float perimetro = 4 * lado;

    // Exiba os resultados
    printf("Área do quadrado: %.2f\n", area);
    printf("Perímetro do quadrado: %.2f\n", perimetro);

    return 0;
}