#include <stdio.h>

int main() {
    int populacaoA = 5000000, populacaoB = 7000000;
    float taxaA = 0.03, taxaB = 0.02;
    int anos = 0;

    while (populacaoA <= populacaoB) {
        populacaoA += populacaoA * taxaA;
        populacaoB += populacaoB * taxaB;
        anos++;
    }

    printf("Tempo necessário para a população do país A ultrapassar B: %d anos\n", anos);

    return 0;
}