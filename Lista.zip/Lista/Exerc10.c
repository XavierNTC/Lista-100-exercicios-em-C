#include <stdio.h>

int main() {
    // Declare a variável para armazenar o inteiro
    int numero;

    // Solicite que o usuário insira um inteiro menor que 32
    printf("Digite um inteiro menor que 32: ");
    scanf("%d", &numero);

    // Verifique se o número está dentro da faixa permitida
    if (numero < 32 && numero >= 0) {
        // Inicialize um vetor para armazenar a representação binária
        int binario[5] = {0, 0, 0, 0, 0};

        // Calcule a representação binária
        int i = 4;
        while (numero > 0) {
            binario[i] = numero % 2;
            numero /= 2;
            i--;
        }

        // Exiba a representação binária
        printf("A representação binária é: ");
        for (i = 0; i < 5; i++) {
            printf("%d", binario[i]);
        }
        printf("\n");
    } else {
        printf("O número inserido não é válido. Certifique-se de que é menor que 32 e maior ou igual a 0.\n");
    }

    return 0;
}