#include <stdio.h>

int main() {
    int array[10];
    int contadorPares = 0;

    printf("Digite 10 números:\n");

    for (int i = 0; i < 10; i++) {
        scanf("%d", &array[i]);

        if (array[i] % 2 == 0) {
            contadorPares++;
        }
    }

    printf("Quantidade de números pares: %d\n", contadorPares);

    return 0;
}
