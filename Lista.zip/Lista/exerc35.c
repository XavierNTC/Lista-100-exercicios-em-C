#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número do dia da semana
    int numDiaSemana;

    // Solicite que o usuário insira o número do dia da semana
    printf("Digite um número de 1 a 7 correspondente ao dia da semana: ");
    scanf("%d", &numDiaSemana);

    // Determine o dia da semana correspondente e exiba-o
    switch (numDiaSemana) {
        case 1:
            printf("Domingo\n");
            break;
        case 2:
            printf("Segunda-feira\n");
            break;
        case 3:
            printf("Terça-feira\n");
            break;
        case 4:
            printf("Quarta-feira\n");
            break;
        case 5:
            printf("Quinta-feira\n");
            break;
        case 6:
            printf("Sexta-feira\n");
            break;
        case 7:
            printf("Sábado\n");
            break;
        default:
            printf("Número inválido. Por favor, insira um número de 1 a 7.\n");
            break;
    }

    return 0;
}