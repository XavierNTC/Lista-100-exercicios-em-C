#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os três números
    float num1, num2, num3;

    // Solicite que o usuário insira os três números
    printf("Digite três números separados por espaços: ");
    scanf("%f %f %f", &num1, &num2, &num3);

    // Calcule a média ponderada
    float mediaPonderada = (num1 * 5 + num2 * 2.5 + num3 * 2.5) / 10;

    printf("A média ponderada é: %.2f\n", mediaPonderada);

    return 0;
}