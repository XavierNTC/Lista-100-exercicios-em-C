#include <stdio.h>

int main() {
    // Declare a variável para armazenar os 4 primeiros dígitos da agência
    int agencia;

    // Solicite que o usuário insira os 4 primeiros dígitos da agência
    printf("Digite os 4 primeiros dígitos da agência: ");
    scanf("%d", &agencia);

    // Extraia cada dígito da agência
    int alg1 = agencia % 10;
    agencia /= 10;
    int alg2 = agencia % 10;
    agencia /= 10;
    int alg3 = agencia % 10;
    agencia /= 10;
    int alg4 = agencia % 10;

    // Calcule o dígito verificador usando o método módulo 11
    int soma = alg1 * 5 + alg2 * 4 + alg3 * 3 + alg4 * 2;
    int resto = soma % 11;
    int dv = 11 - resto;

    // Substitua o valor do dígito verificador por X quando for 10
    if (dv == 10) {
        printf("Número da agência completo: %d-X\n", agencia * 1000 + alg4 * 100 + alg3 * 10 + alg2);
    } else {
        printf("Número da agência completo: %d-%d\n", agencia * 1000 + alg4 * 100 + alg3 * 10 + alg2, dv);
    }

    return 0;
}