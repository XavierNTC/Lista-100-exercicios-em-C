#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os três valores
    int num1, num2, num3;

    // Solicite que o usuário insira os três valores
    printf("Digite três números separados por espaços: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    // Encontre e exiba a soma dos dois maiores
    int somaMaiores = (num1 + num2 + num3) - (num1 < num2 ? num1 : num2) - (num2 < num3 ? num2 : num3);

    printf("A soma dos dois maiores números é: %d\n", somaMaiores);

    return 0;
}