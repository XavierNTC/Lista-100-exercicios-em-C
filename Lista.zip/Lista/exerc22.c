#include <stdio.h>
#include <stdlib.h> // Necessário para a função abs()

int main() {
    // Declare a variável para armazenar o número
    int numero;

    // Solicite que o usuário insira o número
    printf("Digite um número: ");
    scanf("%d", &numero);

    // Calcule e exiba o módulo do número
    int modulo = abs(numero);
    printf("O módulo do número é: %d\n", modulo);

    return 0;
}