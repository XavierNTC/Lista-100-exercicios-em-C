#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar o número de litros e o tipo de combustível
    float litros;
    char tipoCombustivel;

    // Solicite que o usuário insira o número de litros e o tipo de combustível
    printf("Digite o número de litros vendidos: ");
    scanf("%f", &litros);

    printf("Digite o tipo de combustível (A para álcool, G para gasolina): ");
    scanf(" %c", &tipoCombustivel);

    // Verifique o tipo de combustível e calcule o valor a ser pago pelo cliente
    float precoAlcool = 1.9;
    float precoGasolina = 2.7;
    float valorPago;

    if (tipoCombustivel == 'A' || tipoCombustivel == 'a') {
        // Álcool
        if (litros <= 25) {
            valorPago = litros * (precoAlcool - precoAlcool * 0.02);
        } else {
            valorPago = litros * (precoAlcool - precoAlcool * 0.04);
        }
    } else if (tipoCombustivel == 'G' || tipoCombustivel == 'g') {
        // Gasolina
        if (litros <= 25) {
            valorPago = litros * (precoGasolina - precoGasolina * 0.03);
        } else {
            valorPago = litros * (precoGasolina - precoGasolina * 0.05);
        }
    } else {
        printf("Tipo de combustível inválido.\n");
        return 1; // Código de erro
    }

     }