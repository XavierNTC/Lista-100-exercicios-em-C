#include <stdio.h>

int main() {
    int numero;
    printf("Digite um número: ");
    scanf("%d", &numero);

    if (numero >= 2 && numero <= 12) {
        printf("Combinações que resultam em %d:\n", numero);
        for (int dado1 = 1; dado1 <= 6; dado1++) {
            for (int dado2 = 1; dado2 <= 6; dado2++) {
                if (dado1 + dado2 == numero) {
                    printf("%d %d\n", dado1, dado2);
                }
            }
        }
    } else {
        printf("Número inválido para combinação de dados.\n");
    }

    return 0;
}