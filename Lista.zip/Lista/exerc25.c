#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número equivalente ao mês
    int mes;

    // Solicite que o usuário insira o número equivalente ao mês
    printf("Digite o número equivalente ao mês: ");
    scanf("%d", &mes);

    // Verifique e exiba a quantidade de dias no mês
    switch (mes) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            printf("O mês tem 31 dias.\n");
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            printf("O mês tem 30 dias.\n");
            break;
        case 2:
            printf("O mês tem 28 ou 29 dias, dependendo do ano.\n");
            break;
        default:
            printf("Número de mês inválido.\n");
    }

    return 0;
}