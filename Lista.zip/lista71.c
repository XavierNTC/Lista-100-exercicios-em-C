#include <stdio.h>


int buscaSequencial(int vetor[], int tamanho, int elemento) {
    for (int i = 0; i < tamanho; i++) {
        if (vetor[i] == elemento) {
            return i; 
        }
    }
    return -1; 
}

int main() {
    int vetor[10];
    int elemento, posicao;

    printf("Digite os 10 elementos do vetor:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &vetor[i]);
    }

    printf("Digite o inteiro a ser buscado:\n");
    scanf("%d", &elemento);

    posicao = buscaSequencial(vetor, 10, elemento);

    if (posicao != -1) {
        printf("O inteiro foi encontrado na posição %d.\n", posicao);
    } else {
        printf("O inteiro nao foi encontrado no vetor.\n");
    }

    return 0;
}
