#include <stdio.h>

int tempoParaUltrapassarPopulacao(int populacaoA, float taxaNatalidadeA, int populacaoB, float taxaNatalidadeB) {
    int anos = 0;
    while (populacaoA <= populacaoB) {
        populacaoA *= (1 + taxaNatalidadeA / 100);
        populacaoB *= (1 + taxaNatalidadeB / 100);
        anos++;
    }
    return anos;
}

int main() {
    int populacaoA = 5000000;
    float taxaNatalidadeA = 3.0;
    int populacaoB = 7000000;
    float taxaNatalidadeB = 2.0;

    int tempo = tempoParaUltrapassarPopulacao(populacaoA, taxaNatalidadeA, populacaoB, taxaNatalidadeB);

    printf("O tempo necessário para a população do país A ultrapassar a população do país B é de %d anos.\n", tempo);

    return 0;
}
