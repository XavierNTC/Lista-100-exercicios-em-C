#include <stdio.h>
#include <string.h>

void gerarSubstring(const char *original, int inicio, int fim, char *substring) {
    int tamanhoOriginal = strlen(original);
    int tamanhoSubstring = fim - inicio + 1;

    if (inicio >= 0 && inicio <= tamanhoOriginal - 1 && fim >= inicio && fim <= tamanhoOriginal - 1) {
    
        strncpy(substring, original + inicio, tamanhoSubstring);
        substring[tamanhoSubstring] = '\0';  
    } else {

        substring[0] = '\0';
    }
}

int main() {
    char original[100];
    char substring[100];
    int inicio, fim;

    fgets(original, sizeof(original), stdin);

    original[strcspn(original, "\n")] = '\0';

    printf("Digite a posição inicial da substring: ");
    scanf("%d", &inicio);

    printf("Digite a posição final da substring: ");
    scanf("%d", &fim);

    gerarSubstring(original, inicio, fim, substring);

    printf("Substring: %s\n", substring);

    return 0;
}
