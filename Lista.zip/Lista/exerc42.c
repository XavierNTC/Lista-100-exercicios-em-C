#include <stdio.h>

int main() {
    // Imprima todos os números inteiros do intervalo fechado de 100 a 1 em ordem decrescente
    for (int i = 100; i >= 1; i--) {
        printf("%d ", i);
    }
    printf("\n");

    return 0;
}