#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>


int hexParaDecimal(char caractere) {
    if (caractere >= '0' && caractere <= '9') {
        return caractere - '0';
    } else if (caractere >= 'A' && caractere <= 'F') {
        return caractere - 'A' + 10;
    } else if (caractere >= 'a' && caractere <= 'f') {
        return caractere - 'a' + 10;
    } else {
        return -1; 
    }
}


unsigned long long hexStringParaDecimal(const char *hexString) {
    int tamanho = strlen(hexString);
    unsigned long long decimal = 0;

    for (int i = 0; i < tamanho; ++i) {
        int valor = hexParaDecimal(hexString[i]);

        if (valor == -1) {
            printf("Erro: Caractere hexadecimal inválido: %c\n", hexString[i]);
            exit(EXIT_FAILURE);
        }

        
        decimal = decimal * 16 + valor;
    }

    return decimal;
}

int main() {
    char hexString[100];

 
    printf("Digite um número hexadecimal: ");
    scanf("%s", hexString);

    
    unsigned long long decimal = hexStringParaDecimal(hexString);

    
    printf("O número decimal equivalente é: %llu\n", decimal);

    return 0;
}
