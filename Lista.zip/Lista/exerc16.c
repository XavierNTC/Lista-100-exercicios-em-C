#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número de três algarismos
    int numero;

    // Solicite que o usuário insira o número de três algarismos
    printf("Digite um número de três algarismos: ");
    scanf("%d", &numero);

    // Verifique se o número possui três algarismos
    if (numero >= 100 && numero <= 999) {
        // Calcule o número invertido
        int invertido = 0;
        while (numero > 0) {
            invertido = invertido * 10 + numero % 10;
            numero /= 10;
        }

        // Exiba o número invertido
        printf("O número invertido é: %d\n", invertido);
    } else {
        printf("Por favor, digite um número de três algarismos.\n");
    }

    return 0;
}