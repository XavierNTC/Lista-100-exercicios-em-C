#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os números
    int dividendo, divisor;

    // Solicite que o usuário insira dois números inteiros
    printf("Digite o dividendo: ");
    scanf("%d", &dividendo);

    printf("Digite o divisor: ");
    scanf("%d", &divisor);

    // Verifique se o divisor é diferente de zero para evitar divisão por zero
    if (divisor != 0) {
        // Calcule o quociente e o resto
        int quociente = dividendo / divisor;
        int resto = dividendo % divisor;

        // Exiba os resultados
        printf("Quociente: %d\n", quociente);
        printf("Resto: %d\n", resto);
    } else {
        printf("Não é possível dividir por zero.\n");
    }

    return 0;
}