#include <stdio.h>

int main() {
    // Declare a variável para o ano
    int ano;

    // Solicite que o usuário insira o ano
    printf("Digite um ano: ");
    scanf("%d", &ano);

    // Verifique se o ano é bissexto
    if ((ano % 4 == 0 && ano % 100 != 0) || (ano % 400 == 0)) {
        printf("%d é um ano bissexto.\n", ano);
    } else {
        printf("%d não é um ano bissexto.\n", ano);
    }

    return 0;
}