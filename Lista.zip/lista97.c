#include <stdio.h>

#define TAMANHO 5


void exibirMatriz(int matriz[][TAMANHO]) {
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}


void trocarLinhas(int matriz[][TAMANHO], int x, int y) {
    int temp[TAMANHO];
    for (int i = 0; i < TAMANHO; ++i) {
        temp[i] = matriz[x][i];
        matriz[x][i] = matriz[y][i];
        matriz[y][i] = temp[i];
    }
}


void trocarColunas(int matriz[][TAMANHO], int x, int y) {
    int temp[TAMANHO];
    for (int i = 0; i < TAMANHO; ++i) {
        temp[i] = matriz[i][x];
        matriz[i][x] = matriz[i][y];
        matriz[i][y] = temp[i];
    }
}


void trocarDiagonais(int matriz[][TAMANHO]) {
    int temp;
    for (int i = 0; i < TAMANHO; ++i) {
        temp = matriz[i][i];
        matriz[i][i] = matriz[i][TAMANHO - 1 - i];
        matriz[i][TAMANHO - 1 - i] = temp;
    }
}

int main() {
    int matriz[TAMANHO][TAMANHO];
    int x, y;

    
    printf("Digite os valores para preencher a matriz 5x5:\n");
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

  
    printf("\nMatriz Original:\n");
    exibirMatriz(matriz);

   
    printf("Digite os valores x e y para trocar as linhas, colunas e diagonais: ");
    scanf("%d %d", &x, &y);

    
    trocarLinhas(matriz, x, y);

   
    trocarColunas(matriz, x, y);

  
    trocarDiagonais(matriz);

    
    printf("\nMatriz Modificada:\n");
    exibirMatriz(matriz);

    return 0;
}
