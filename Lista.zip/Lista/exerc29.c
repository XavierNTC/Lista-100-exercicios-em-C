#include <stdio.h>

int main() {
    // Declare a variável para armazenar o salário
    float salario;

    // Solicite que o usuário insira o salário
    printf("Digite o salário do funcionário: R$ ");
    scanf("%f", &salario);

    // Calcule o desconto previdenciário
    float desconto = salario * 0.11;
    
    // Limite o desconto ao valor máximo de R$ 334,29
    if (desconto > 334.29) {
        desconto = 334.29;
    }

    // Exiba o valor do desconto
    printf("O desconto previdenciário é: R$ %.2f\n", desconto);

    return 0;
}