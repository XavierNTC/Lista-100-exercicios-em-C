#include <stdio.h>
#include <string.h>

int valorRomano(char caractere) {
    switch (caractere) {
        case 'I': return 1;
        case 'V': return 5;
        case 'X': return 10;
        case 'L': return 50;
        case 'C': return 100;
        case 'D': return 500;
        case 'M': return 1000;
        default:  return 0; 
    }
}


int romanoParaDecimal(const char *romano) {
    int tamanho = strlen(romano);
    int resultado = 0;

    for (int i = 0; i < tamanho; ++i) {
        int valorAtual = valorRomano(romano[i]);

        if (valorAtual == 0) {
            printf("Erro: Caractere romano inválido: %c\n", romano[i]);
            return -1;
        }

        if (i + 1 < tamanho && valorRomano(romano[i + 1]) > valorAtual) {
            resultado -= valorAtual;
        } else {
            resultado += valorAtual;
        }
    }

    return resultado;
}

int main() {
    char romano[20];

    
    printf("Digite um número em romano: ");
    scanf("%s", romano);

    
    int decimal = romanoParaDecimal(romano);

   
    if (decimal != -1) {
        printf("O número decimal equivalente é: %d\n", decimal);
    }

    return 0;
}
