#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número
    int numero;

    // Solicite que o usuário insira o número
    printf("Digite um número: ");
    scanf("%d", &numero);

    // Verifique se o número é par ou ímpar
    if (numero % 2 == 0) {
        printf("O número é par.\n");
    } else {
        printf("O número é ímpar.\n");
    }

    return 0;
}