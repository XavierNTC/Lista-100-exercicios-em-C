#include <stdio.h>
#include <math.h>

#define PI 3.14159265

int main() {
    // Defina o tamanho do raio da circunferência
    float raio;
    printf("Digite o tamanho do raio da circunferência: ");
    scanf("%f", &raio);

    // Calcule a área e o perímetro
    float area = PI * pow(raio, 2);
    float perimetro = 2 * PI * raio;

    // Exiba os resultados
    printf("Área da circunferência: %.2f\n", area);
    printf("Perímetro da circunferência: %.2f\n", perimetro);

    return 0;
}