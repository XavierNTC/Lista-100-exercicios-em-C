#include <stdio.h>

// Função para calcular o número de Euler (e) usando a série fornecida
double calcularEuler(int N) {
    double e = 1.0;
    double termo = 1.0;

    for (int i = 1; i <= N; i++) {
        termo /= i;
        e += termo;
    }

    return e;
}

int main() {
    int N;

    printf("Digite o valor de N: ");
    scanf("%d", &N);

    double resultadoEuler = calcularEuler(N);

    printf("O valor de Euler (e) usando os primeiros %d termos é: %.15f\n", N, resultadoEuler);

    return 0;
}
