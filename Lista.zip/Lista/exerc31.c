#include <stdio.h>

int main() {
    // Declare as variáveis para as estatísticas do quarterback
    int passesTentados, passesCompletos, jardasPassadas, passesTouchdown, passesInterceptados;

    // Solicite que o usuário insira as estatísticas
    printf("Digite o número de passes tentados: ");
    scanf("%d", &passesTentados);

    printf("Digite o número de passes completos: ");
    scanf("%d", &passesCompletos);

    printf("Digite o número de jardas passadas: ");
    scanf("%d", &jardasPassadas);

    printf("Digite o número de passes para touchdown: ");
    scanf("%d", &passesTouchdown);

    printf("Digite o número de passes interceptados: ");
    scanf("%d", &passesInterceptados);

    // Calcula o percentual de passes completados
    float completacao = ((float)passesCompletos / passesTentados - 0.3) / 0.2;
    if (completacao > 2.375) completacao = 2.375;
    if (completacao < 0) completacao = 0;

    // Calcula a razão de jardas passadas por passes tentados
    float jardasPorPasse = ((float)jardasPassadas / passesTentados - 3) / 4;
    if (jardasPorPasse > 2.375) jardasPorPasse = 2.375;
    if (jardasPorPasse < 0) jardasPorPasse = 0;

    // Calcula a razão de passes para touchdown por passes tentados
    float touchdownPorPasse = ((float)passesTouchdown / passesTentados) / 0.05;
    if (touchdownPorPasse > 2.375) touchdownPorPasse = 2.375;
    if (touchdownPorPasse < 0) touchdownPorPasse = 0;

    // Calcula a razão de passes interceptados por passes tentados
    float interceptacaoPorPasse = ((float)passesInterceptados / passesTentados - 0.095) / 0.04;
    if (interceptacaoPorPasse > 2.375) interceptacaoPorPasse = 2.375;
    if (interceptacaoPorPasse < 0) interceptacaoPorPasse = 0;

    // Calcula o QB Rating
    float qbRating = (completacao + jardasPorPasse + touchdownPorPasse + interceptacaoPorPasse) * 100 / 6;

    // Exibe o QB Rating do quarterback
    printf("O QB Rating do quarterback é: %.2f\n", qbRating);

    return 0;
}