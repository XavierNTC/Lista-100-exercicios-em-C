#include <stdio.h>

#define TAMANHO 5

int ehSimetrica(int matriz[][TAMANHO]) {
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            
            if (matriz[i][j] != matriz[j][i]) {
                return 0; 
            }
        }
    }
    return 1;
}

int main() {
    int matriz[TAMANHO][TAMANHO];

   
    printf("Digite os valores para preencher a matriz 5x5:\n");
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

    
    if (ehSimetrica(matriz)) {
        printf("\nA matriz é simétrica.\n");
    } else {
        printf("\nA matriz não é simétrica.\n");
    }

    return 0;
}
