#include <stdio.h>

// Função para verificar se um número é primo
int ehPrimo(int num) {
    if (num <= 1) {
        return 0; // Números menores ou iguais a 1 não são primos
    }
    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            return 0; // Se encontrou um divisor, não é primo
        }
    }
    return 1; // Se não encontrou divisores, é primo
}

int main() {
    for (int num = 500; num <= 1000; num += 2) {
        for (int i = 2; i <= num / 2; i++) {
            if (ehPrimo(i) && ehPrimo(num - i)) {
                printf("%d = %d + %d\n", num, i, num - i);
                break;
            }
        }
    }

    return 0;
}
