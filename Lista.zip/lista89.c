#include <stdio.h>
#include <string.h>
#include <ctype.h>

void gerarStringFormatada(const char *nomeCompleto, char *stringFormatada) {
    const char *ultimoNome;
    const char *token;
    char iniciais[20] = "";

   
    token = strtok((char *)nomeCompleto, " ");
    while (token != NULL) {
        ultimoNome = token;
        token = strtok(NULL, " ");
    }

    
    sprintf(stringFormatada, "%s, ", ultimoNome);

    
    token = strtok((char *)nomeCompleto, " ");
    while (token != NULL) {
        if (token != ultimoNome) {
            strncat(iniciais, token, 1);
            strncat(iniciais, ". ", 2);
        }
        token = strtok(NULL, " ");
    }

   
    for (int i = 0; iniciais[i] != '\0'; i++) {
        iniciais[i] = toupper(iniciais[i]);
    }

   
    strcat(stringFormatada, iniciais);

    
    stringFormatada[strlen(stringFormatada) - 1] = '\0';
}

int main() {
    char nomeCompleto[100];
    char stringFormatada[100];

    
    printf("Digite um nome completo: ");
    fgets(nomeCompleto, sizeof(nomeCompleto), stdin);

    
    nomeCompleto[strcspn(nomeCompleto, "\n")] = '\0';

   
    gerarStringFormatada(nomeCompleto, stringFormatada);

   
    printf("String formatada: %s\n", stringFormatada);

    return 0;
}
