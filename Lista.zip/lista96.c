#include <stdio.h>

#define LINHAS 3
#define COLUNAS 4

void somarMatrizes(int matriz1[][COLUNAS], int matriz2[][COLUNAS], int resultado[][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }
}

void subtrairMatrizes(int matriz1[][COLUNAS], int matriz2[][COLUNAS], int resultado[][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            resultado[i][j] = matriz1[i][j] - matriz2[i][j];
        }
    }
}

void exibirMatriz(int matriz[][COLUNAS]) {
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}

int main() {
    int matriz1[LINHAS][COLUNAS];
    int matriz2[LINHAS][COLUNAS];
    int matrizSoma[LINHAS][COLUNAS];
    int matrizDiferenca[LINHAS][COLUNAS];

    printf("Digite os valores para preencher a primeira matriz 3x4:\n");
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            printf("Matriz1[%d][%d]: ", i, j);
            scanf("%d", &matriz1[i][j]);
        }
    }
    
    printf("\nDigite os valores para preencher a segunda matriz 3x4:\n");
    for (int i = 0; i < LINHAS; ++i) {
        for (int j = 0; j < COLUNAS; ++j) {
            printf("Matriz2[%d][%d]: ", i, j);
            scanf("%d", &matriz2[i][j]);
        }
    }

    somarMatrizes(matriz1, matriz2, matrizSoma);
    printf("\nMatriz Soma (Matriz1 + Matriz2):\n");
    exibirMatriz(matrizSoma);
    
    subtrairMatrizes(matriz1, matriz2, matrizDiferenca);
    printf("Matriz Diferença (Matriz1 - Matriz2):\n");
    exibirMatriz(matrizDiferenca);

    return 0;
}
