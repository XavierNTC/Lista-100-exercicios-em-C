#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar as notas
    float bimestre1_prova1, bimestre1_prova2, bimestre2_prova1, bimestre2_prova2;

    // Solicite que o usuário insira as notas das provas do primeiro bimestre
    printf("Digite as notas das provas do primeiro bimestre:\n");
    printf("Prova 1: ");
    scanf("%f", &bimestre1_prova1);
    printf("Prova 2: ");
    scanf("%f", &bimestre1_prova2);

    // Solicite que o usuário insira as notas das provas do segundo bimestre
    printf("\nDigite as notas das provas do segundo bimestre:\n");
    printf("Prova 1: ");
    scanf("%f", &bimestre2_prova1);
    printf("Prova 2: ");
    scanf("%f", &bimestre2_prova2);

    // Calcule a nota semestral (média aritmética)
    float nota_semestral = (bimestre1_prova1 + bimestre1_prova2 + bimestre2_prova1 + bimestre2_prova2) / 4;

    // Exiba a nota semestral
    printf("\nA nota semestral do aluno é: %.2f\n", nota_semestral);

    return 0;
 }