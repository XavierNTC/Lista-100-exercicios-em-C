#include <stdio.h>

int buscaBinaria(int vetor[], int inicio, int fim, int elemento) {
    while (inicio <= fim) {
        int meio = inicio + (fim - inicio) / 2;

        if (vetor[meio] == elemento) {
            return meio; 
        }

        if (vetor[meio] > elemento) {
            fim = meio - 1;
        }
        
        else {
            inicio = meio + 1;
        }
    }

    return -1;  

int main() {
    const int tamanhoVetor = 10;
    int vetor[tamanhoVetor];
    int elemento;

    printf("Digite os 10 elementos do vetor (ordenados):\n");
    for (int i = 0; i < tamanhoVetor; ++i) {
        scanf("%d", &vetor[i]);
    }

    printf("Digite o elemento a ser procurado: ");
    scanf("%d", &elemento);

    int posicao = buscaBinaria(vetor, 0, tamanhoVetor - 1, elemento);

    
    if (posicao != -1) {
        printf("O elemento %d foi encontrado na posição %d.\n", elemento, posicao);
    } else {
        printf("O elemento %d não foi encontrado no vetor.\n", elemento);
    }

    return 0;
}
