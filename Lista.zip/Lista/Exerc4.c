#include <stdio.h>

int main() {
    // Defina os três lados do triângulo
    float lado1, lado2, lado3;
    printf("Digite os três lados do triângulo:\n");
    scanf("%f %f %f", &lado1, &lado2, &lado3);

    // Calcule o perímetro
    float perimetro = lado1 + lado2 + lado3;

    // Exiba o resultado
    printf("Perímetro do triângulo: %.2f\n", perimetro);

    return 0;
}