#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número
    int numero;

    // Solicite que o usuário insira o número
    printf("Digite um número: ");
    scanf("%d", &numero);

    // Verifique se o número é positivo, negativo ou zero
    if (numero > 0) {
        printf("O número é positivo.\n");
    } else if (numero < 0) {
        printf("O número é negativo.\n");
    } else {
        printf("O número é zero.\n");
    }

    return 0;
}