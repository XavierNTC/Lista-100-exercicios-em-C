#include <stdio.h>
#include <ctype.h>

void converterParaCaixaAlta(char *str) {
    while (*str != '\0') {
        *str = toupper(*str);  
        str++;
    }
}

int main() {
    char string[100];

    
    printf("Digite uma string: ");
    fgets(string, sizeof(string), stdin);

   
    string[strcspn(string, "\n")] = '\0';


    converterParaCaixaAlta(string);

    
    printf("String em caixa alta: %s\n", string);

    return 0;
}
