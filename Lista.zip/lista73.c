#include <stdio.h>

void ordenarArray(int array[], int tamanho) {
    int temp;
    for (int i = 0; i < tamanho - 1; ++i) {
        for (int j = 0; j < tamanho - i - 1; ++j) {
            if (array[j] > array[j + 1]) {
                temp = array[j];
                array[j] = array[j + 1];
                array[j + 1] = temp;
            }
        }
    }
}

int calcularModa(int array[], int tamanho) {
    int moda = array[0];
    int contagemAtual = 1;
    int contagemMaxima = 1;

    for (int i = 1; i < tamanho; ++i) {
        if (array[i] == array[i - 1]) {
            contagemAtual++;
        } else {
            contagemAtual = 1;
        }

        if (contagemAtual > contagemMaxima) {
            contagemMaxima = contagemAtual;
            moda = array[i];
        }
    }

    return moda;
}

float calcularMediana(int array[], int tamanho) {
    if (tamanho % 2 == 0) {
        return (array[tamanho / 2 - 1] + array[tamanho / 2]) / 2.0;
    } else {
        return array[tamanho / 2];
    }
}

float calcularMedia(int array[], int tamanho) {
    float soma = 0;

    for (int i = 0; i < tamanho; ++i) {
        soma += array[i];
    }

    return soma / tamanho;
}

int main() {
    const int tamanhoArray = 20;
    int array[tamanhoArray];

    printf("Digite os 20 elementos do array:\n");
    for (int i = 0; i < tamanhoArray; ++i) {
        scanf("%d", &array[i]);
    }

    ordenarArray(array, tamanhoArray);
    
    printf("Moda: %d\n", calcularModa(array, tamanhoArray));
    printf("Mediana: %.2f\n", calcularMediana(array, tamanhoArray));
    printf("Média: %.2f\n", calcularMedia(array, tamanhoArray));

    return 0;
}
