#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os valores
    int a, b;

    // Solicite que o usuário insira os valores das variáveis
    printf("Digite o valor de a: ");
    scanf("%d", &a);

    printf("Digite o valor de b: ");
    scanf("%d", &b);

    // Exiba os valores originais
    printf("\nValores originais:\n");
    printf("a: %d\n", a);
    printf("b: %d\n", b);

    // Permute os valores
    int temp = a;
    a = b;
    b = temp;

    // Exiba os valores após a permutação
    printf("\nValores após a permutação:\n");
    printf("a: %d\n", a);
    printf("b: %d\n", b);

    return 0;
}