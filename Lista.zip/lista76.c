#include <stdio.h>
#include <string.h>

int contarVogais(const char *str) {
    int contador = 0;
    int tamanho = strlen(str);

    for (int i = 0; i < tamanho; ++i) {
        char caractere = str[i];
        
        switch (tolower(caractere)) {
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                contador++;
                break;
        }
    }

    return contador;
}

int main() {
    char string[100];

    printf("Digite uma string: ");
    fgets(string, sizeof(string), stdin);

    string[strcspn(string, "\n")] = '\0';

    int quantidadeVogais = contarVogais(string);

    printf("Número de vogais na string: %d\n", quantidadeVogais);

    return 0;
}
