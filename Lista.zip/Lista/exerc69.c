#include <stdio.h>

int main() {
    int vetor[15];
    int valorProcurado, contadorOcorrencias = 0;

    printf("Digite 15 números para o vetor:\n");
    for (int i = 0; i < 15; i++) {
        scanf("%d", &vetor[i]);
    }

    printf("Digite o valor a ser procurado: ");
    scanf("%d", &valorProcurado);

    for (int i = 0; i < 15; i++) {
        if (vetor[i] == valorProcurado) {
            contadorOcorrencias++;
        }
    }

    printf("O valor %d ocorre %d vezes no vetor.\n", valorProcurado, contadorOcorrencias);

    return 0;
}
