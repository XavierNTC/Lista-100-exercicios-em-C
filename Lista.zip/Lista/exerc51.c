#include <stdio.h>

void combinaçõesLançamentoDados(int somaDesejada) {
    for (int dado1 = 1; dado1 <= 6; dado1++) {
        for (int dado2 = 1; dado2 <= 6; dado2++) {
            if (dado1 + dado2 == somaDesejada) {
                printf("%d %d\n", dado1, dado2);
            }
        }
    }
}

int main() {
    // Lê o valor desejado
    int numeroLido;
    printf("Digite um número: ");
    scanf("%d", &numeroLido);

    // Chama a função para imprimir as combinações
    combinaçõesLançamentoDados(numeroLido);

    return 0;
}
