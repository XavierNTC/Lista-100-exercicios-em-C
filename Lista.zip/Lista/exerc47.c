#include <stdio.h>

int main() {
    int N, termo1, termo2;
    printf("Digite os dois primeiros termos da série de FETUCCINE: ");
    scanf("%d %d", &termo1, &termo2);
    
    if (N >= 3) {
        printf("Primeiros %d termos da série de FETUCCINE:\n", N);
        printf("%d %d ", termo1, termo2);
        for (int i = 3; i <= N; i++) {
            if (i % 2 == 1) {
                termo1 = termo1 + termo2;
            } else {
                termo1 = termo1 - termo2;
            }
            printf("%d ", termo1);
        }
    } else {
        printf("Série de FETUCCINE requer pelo menos três termos.");
    }

    return 0;
}