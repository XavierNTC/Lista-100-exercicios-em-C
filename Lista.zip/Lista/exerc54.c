#include <stdio.h>

int ehTriangular(int numero) {
    int produto = 1;
    int i = 1;
    while (produto < numero) {
        produto *= i;
        i++;
    }
    return produto == numero;
}

int main() {
    int numeroDigitado;

    printf("Digite um número: ");
    scanf("%d", &numeroDigitado);

    if (ehTriangular(numeroDigitado)) {
        printf("%d é um número triangular.\n", numeroDigitado);
    } else {
        printf("%d não é um número triangular.\n", numeroDigitado);
    }

    return 0;
}
