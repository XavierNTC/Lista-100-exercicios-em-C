#include <stdio.h>

int main() {
    // Declare a variável para armazenar a temperatura em Fahrenheit
    float temperaturaFahrenheit;

    // Solicite que o usuário insira a temperatura em Fahrenheit
    printf("Digite a temperatura em Fahrenheit: ");
    scanf("%f", &temperaturaFahrenheit);

    // Converta a temperatura para Celsius usando a fórmula C = 5/9 * (F - 32)
    float temperaturaCelsius = (temperaturaFahrenheit - 32) * 5 / 9;

    // Exiba a temperatura em Celsius
    printf("A temperatura em Celsius é: %.2f\n", temperaturaCelsius);

    return 0;
}