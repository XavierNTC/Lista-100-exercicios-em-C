#include <stdio.h>
#include <string.h>

int contemString(const char *str1, const char *str2) {
    int tamanhoStr1 = strlen(str1);
    int tamanhoStr2 = strlen(str2);

    if (tamanhoStr1 < tamanhoStr2) {
        return 0; 
    }

    for (int i = 0; i <= tamanhoStr1 - tamanhoStr2; ++i) {
        int j;
        for (j = 0; j < tamanhoStr2; ++j) {
            if (str1[i + j] != str2[j]) {
                break; 
            }
        }

        if (j == tamanhoStr2) {
            return 1; 
        }
    }

    return 0; 
}

int main() {
    char str1[100];
    char str2[100];

    printf("Digite a primeira string: ");
    fgets(str1, sizeof(str1), stdin);

    str1[strcspn(str1, "\n")] = '\0';

    printf("Digite a segunda string: ");
    fgets(str2, sizeof(str2), stdin);

    str2[strcspn(str2, "\n")] = '\0';

    if (contemString(str1, str2)) {
        printf("A primeira string contém a segunda.\n");
    } else {
        printf("A primeira string não contém a segunda.\n");
    }

    return 0;
}
