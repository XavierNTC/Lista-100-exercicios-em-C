#include <stdio.h>
#include <ctype.h>

void normalizarString(const char *original, char *normalizada) {
    int i, j;
    int tamanho = 0;
    int flagEspaco = 0; 

    for (i = 0, j = 0; original[i] != '\0'; ++i) {
        if (isspace(original[i])) {
            if (!flagEspaco) {
                normalizada[j++] = ' ';
                tamanho++;
            }
            flagEspaco = 1;
        } else {
            normalizada[j++] = original[i];
            tamanho++;
            flagEspaco = 0;
        }
    }

    normalizada[j] = '\0';

    if (tamanho > 0 && normalizada[tamanho - 1] == ' ') {
        normalizada[tamanho - 1] = '\0';
    }
}

int main() {
    char original[100];
    char normalizada[100];

    printf("Digite uma string: ");
    fgets(original, sizeof(original), stdin);

    original[strcspn(original, "\n")] = '\0';

    normalizarString(original, normalizada);

    printf("String normalizada: %s\n", normalizada);

    return 0;
}
