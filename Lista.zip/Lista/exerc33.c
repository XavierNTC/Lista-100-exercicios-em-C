#include <stdio.h>

int main() {
    // Declare as variáveis para as coordenadas do ponto
    float x, y;

    // Solicite que o usuário insira as coordenadas do ponto
    printf("Digite as coordenadas do ponto (x y): ");
    scanf("%f %f", &x, &y);

    // Determine o quadrante ou se está sobre os eixos cartesianos ou na origem
    if (x > 0 && y > 0) {
        printf("O ponto está no primeiro quadrante.\n");
    } else if (x < 0 && y > 0) {
        printf("O ponto está no segundo quadrante.\n");
    } else if (x < 0 && y < 0) {
        printf("O ponto está no terceiro quadrante.\n");
    } else if (x > 0 && y < 0) {
        printf("O ponto está no quarto quadrante.\n");
    } else if (x == 0 && y != 0) {
        printf("O ponto está sobre o eixo Y.\n");
    } else if (x != 0 && y == 0) {
        printf("O ponto está sobre o eixo X.\n");
    } else if (x == 0 && y == 0) {
        printf("O ponto está na origem.\n");
    }

    return 0;
}