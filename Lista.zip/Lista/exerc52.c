algoritmo "FETUCCINE"
var
    n, i, a1, a2, a3: inteiro

inicio
    // Solicita os dois primeiros termos e a quantidade de termos desejada
    escreva("Digite o primeiro termo: ")
    leia(a1)
    escreva("Digite o segundo termo: ")
    leia(a2)
    escreva("Digite a quantidade de termos desejada (N >= 3): ")
    leia(n)

    // Verifica se N é pelo menos 3
    se n < 3 entao
        escreva("A quantidade de termos precisa ser pelo menos 3.")
    senao
        // Imprime os dois primeiros termos
        escreva(a1, " ", a2, " ")

        // Gera os próximos termos da série de FETUCCINE
        para i de 3 ate n faca
            se i mod 2 = 1 entao
                // Para i ímpar: Ai = Ai-1 + Ai-2
                a3 <- a2 + a1
            senao
                // Para i par: Ai = Ai-1 - Ai-2
                a3 <- a2 - a1
            fimse

            // Imprime o termo gerado
            escreva(a3, " ")

            // Atualiza os termos anteriores para o próximo cálculo
            a1 <- a2
            a2 <- a3
        fimpara
    fimse
fimalgoritmo
