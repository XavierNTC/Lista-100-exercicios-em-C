#include <stdio.h>

#define N 3 
#define IDADE_MINIMA 18
#define IDADE_MAXIMA 30


void inicializarMatrizFrequencia(int matriz[][N]) {
    for (int i = 0; i <= IDADE_MAXIMA - IDADE_MINIMA; ++i) {
        for (int j = 0; j <= IDADE_MAXIMA - IDADE_MINIMA; ++j) {
            matriz[i][j] = 0;
        }
    }
}


void exibirMatrizFrequencia(int matriz[][N]) {
    printf("Matriz de Frequência de Idades de Casamento:\n");
    for (int i = 0; i <= IDADE_MAXIMA - IDADE_MINIMA; ++i) {
        for (int j = 0; j <= IDADE_MAXIMA - IDADE_MINIMA; ++j) {
            printf("%d\t", matriz[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}


int idadeMaisFrequente(int vetor[], int tamanho) {
    int frequencia[IDADE_MAXIMA - IDADE_MINIMA + 1] = {0};
    for (int i = 0; i < tamanho; ++i) {
        frequencia[vetor[i] - IDADE_MINIMA]++;
    }

    int maxFrequencia = 0;
    int idadeMaisFrequente = 0;
    for (int i = 0; i <= IDADE_MAXIMA - IDADE_MINIMA; ++i) {
        if (frequencia[i] > maxFrequencia) {
            maxFrequencia = frequencia[i];
            idadeMaisFrequente = i + IDADE_MINIMA;
        }
    }

    return idadeMaisFrequente;
}

int main() {
    int idadesHomens[N], idadesMulheres[N];
    int matrizFrequencia[IDADE_MAXIMA - IDADE_MINIMA + 1][IDADE_MAXIMA - IDADE_MINIMA + 1];

   
    inicializarMatrizFrequencia(matrizFrequencia);

    
    int i;
    for (i = 0; i < N; ++i) {
        printf("Informe a idade do homem no casamento (idade inválida para encerrar): ");
        scanf("%d", &idadesHomens[i]);

        if (idadesHomens[i] < IDADE_MINIMA || idadesHomens[i] > IDADE_MAXIMA) {
            break;
        }

        printf("Informe a idade da mulher no casamento (idade inválida para encerrar): ");
        scanf("%d", &idadesMulheres[i]);

        if (idadesMulheres[i] < IDADE_MINIMA || idadesMulheres[i] > IDADE_MAXIMA) {
            break;
        }

        
        matrizFrequencia[idadesHomens[i] - IDADE_MINIMA][idadesMulheres[i] - IDADE_MINIMA]++;
    }

    
    exibirMatrizFrequencia(matrizFrequencia);

    
    int idadeMaisFrequenteHomens = idadeMaisFrequente(idadesHomens, i);
    int idadeMaisFrequenteMulheres = idadeMaisFrequente(idadesMulheres, i);

    
    printf("Idade mais frequente de casamento dos homens: %d\n", idadeMaisFrequenteHomens);
    printf("Idade mais frequente de casamento das mulheres: %d\n", idadeMaisFrequenteMulheres);

    
    int maxFrequencia = 0;
    int idadeHomemMaisFrequente = 0;
    int idadeMulherMaisFrequente = 0;

    for (int j = 0; j <= IDADE_MAXIMA - IDADE_MINIMA; ++j) {
        for (int k = 0; k <= IDADE_MAXIMA - IDADE_MINIMA; ++k) {
            if (matrizFrequencia[j][k] > maxFrequencia) {
                maxFrequencia = matrizFrequencia[j][k];
                idadeHomemMaisFrequente = j + IDADE_MINIMA;
                idadeMulherMaisFrequente = k + IDADE_MINIMA;
            }
        }
    }

    printf("Combinação mais frequente de idades de casamento: Homem %d e Mulher %d\n", idadeHomemMaisFrequente, idadeMulherMaisFrequente);

    return 0;
}
