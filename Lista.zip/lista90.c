#include <stdio.h>
#include <string.h>
#include <ctype.h>


int ehVogal(char caractere) {
    caractere = tolower(caractere);
    return (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u');
}


void criarNovaString(const char *original, char *novaString) {
    int tamanho = strlen(original);
    int indiceVogais = 0;
    int indiceConsoantes = 0;

    for (int i = 0; i < tamanho; ++i) {
        char caractereAtual = original[i];

        if (isalpha(caractereAtual)) {
            if (ehVogal(caractereAtual)) {
                novaString[indiceVogais++] = caractereAtual;
            } else {
                novaString[tamanho - (++indiceConsoantes)] = caractereAtual;
            }
        }
    }

    novaString[indiceVogais + indiceConsoantes] = '\0';
}

int main() {
    char original[100];
    char novaString[100];

    
    printf("Digite uma string: ");
    fgets(original, sizeof(original), stdin);

    
    original[strcspn(original, "\n")] = '\0';

   
    criarNovaString(original, novaString);

    
    printf("Nova string: %s\n", novaString);

    return 0;
}
