#include <stdio.h>

int main() {
    int vetor1[10], vetor2[10], vetorResultado[10];

    printf("Digite 10 números para o primeiro vetor:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &vetor1[i]);
    }

    printf("Digite 10 números para o segundo vetor:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &vetor2[i]);
    }

    for (int i = 0; i < 10; i++) {
        if (vetor1[i] > vetor2[i]) {
            vetorResultado[i] = vetor1[i];
        } else {
            vetorResultado[i] = vetor2[i];
        }
    }

    printf("Terceiro vetor (maiores valores):\n");
    for (int i = 0; i < 10; i++) {
        printf("%d ", vetorResultado[i]);
    }
    printf("\n");

    return 0;
}
