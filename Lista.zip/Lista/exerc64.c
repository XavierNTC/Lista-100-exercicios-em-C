#include <stdio.h>

int main() {
    int array[20];

    printf("Digite 20 números:\n");
    for (int i = 0; i < 20; i++) {
        scanf("%d", &array[i]);
    }

    int menor = array[0], maior = array[0];

    for (int i = 1; i < 20; i++) {
        if (array[i] < menor) {
            menor = array[i];
        }
        if (array[i] > maior) {
            maior = array[i];
        }
    }

    printf("Menor valor: %d\n", menor);
    printf("Maior valor: %d\n", maior);

    return 0;
}
