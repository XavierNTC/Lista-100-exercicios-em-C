#include <stdio.h>

#define TAMANHO 5


int somaDiagonalPrincipal(int matriz[][TAMANHO]) {
    int soma = 0;
    for (int i = 0; i < TAMANHO; ++i) {
        soma += matriz[i][i];
    }
    return soma;
}


int somaDiagonalSecundaria(int matriz[][TAMANHO]) {
    int soma = 0;
    for (int i = 0; i < TAMANHO; ++i) {
        soma += matriz[i][TAMANHO - 1 - i];
    }
    return soma;
}

int main() {
    int matriz[TAMANHO][TAMANHO];

    
    printf("Digite os valores para preencher a matriz 5x5:\n");
    for (int i = 0; i < TAMANHO; ++i) {
        for (int j = 0; j < TAMANHO; ++j) {
            printf("Matriz[%d][%d]: ", i, j);
            scanf("%d", &matriz[i][j]);
        }
    }

   
    int somaPrincipal = somaDiagonalPrincipal(matriz);
    printf("\nSoma da diagonal principal: %d\n", somaPrincipal);

    
    int somaSecundaria = somaDiagonalSecundaria(matriz);
    printf("Soma da diagonal secundária: %d\n", somaSecundaria);

    return 0;
}
