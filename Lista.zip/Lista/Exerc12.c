#include <stdio.h>

int main() {
    // Declare a variável para armazenar a velocidade em m/s
    float velocidade_ms;

    // Solicite que o usuário insira a velocidade em m/s
    printf("Digite a velocidade em m/s: ");
    scanf("%f", &velocidade_ms);

    // Converta a velocidade para km/h multiplicando por 3,6
    float velocidade_kmh = velocidade_ms * 3.6;

    // Exiba a velocidade em km/h
    printf("A velocidade em km/h é: %.2f\n", velocidade_kmh);

    return 0;
}