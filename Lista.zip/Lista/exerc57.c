#include <stdio.h>

// Função para calcular o somatório S
double calcularS(int N) {
    double S = 1.0;
    double termo = 1.0;

    for (int i = 1; i <= N; i++) {
        termo *= i * 2 - 1;
        termo /= i * 2;
        S += termo;
    }

    return S;
}

int main() {
    int N;

    printf("Digite o valor de N: ");
    scanf("%d", &N);

    double resultadoS = calcularS(N);

    printf("O valor de S para os primeiros %d termos é: %.15f\n", N, resultadoS);

    return 0;
}
