#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número
    int numero;

    // Solicite que o usuário insira um número de 1 a 100
    printf("Digite um número de 1 a 100: ");
    scanf("%d", &numero);

    // Verifique se o número está no intervalo permitido
    if (numero < 1 || numero > 100) {
        printf("Número inválido. Por favor, insira um número de 1 a 100.\n");
        return 1; // Código de erro
    }

    // Array para armazenar os nomes dos números de 1 a 100 por extenso
    char *nomes[] = {"", "Um", "Dois", "Três", "Quatro", "Cinco", "Seis", "Sete", "Oito", "Nove", "Dez",
                     "Onze", "Doze", "Treze", "Catorze", "Quinze", "Dezesseis", "Dezessete", "Dezoito", "Dezenove",
                     "Vinte", "Vinte e Um", "Vinte e Dois", "Vinte e Três", "Vinte e Quatro", "Vinte e Cinco",
                     "Vinte e Seis", "Vinte e Sete", "Vinte e Oito", "Vinte e Nove", "Trinta", "Trinta e Um",
                     "Trinta e Dois", "Trinta e Três", "Trinta e Quatro", "Trinta e Cinco", "Trinta e Seis",
                     "Trinta e Sete", "Trinta e Oito", "Trinta e Nove", "Quarenta", "Quarenta e Um", "Quarenta e Dois",
                     "Quarenta e Três", "Quarenta e Quatro", "Quarenta e Cinco", "Quarenta e Seis", "Quarenta e Sete",
                     "Quarenta e Oito", "Quarenta e Nove", "Cinquenta", "Cinquenta e Um", "Cinquenta e Dois",
                     "Cinquenta e Três", "Cinquenta e Quatro", "Cinquenta e Cinco", "Cinquenta e Seis",
                     "Cinquenta e Sete", "Cinquenta e Oito", "Cinquenta e Nove", "Sessenta", "Sessenta e Um",
                     "Sessenta e Dois", "Sessenta e Três", "Sessenta e Quatro", "Sessenta e Cinco", "Sessenta e Seis",
                     "Sessenta e Sete", "Sessenta e Oito", "Sessenta e Nove", "Setenta", "Setenta e Um", "Setenta e Dois",
                     "Setenta e Três", "Setenta e Quatro", "Setenta e Cinco", "Setenta e Seis", "Setenta e Sete",
                     "Setenta e Oito", "Setenta e Nove", "Oitenta", "Oitenta e Um", "Oitenta e Dois", "Oitenta e Três",
                     "Oitenta e Quatro", "Oitenta e Cinco", "Oitenta e Seis", "Oitenta e Sete", "Oitenta e Oito",
                     "Oitenta e Nove", "Noventa", "Noventa e Um", "Noventa e Dois", "Noventa e Três", "Noventa e Quatro",
                     "Noventa e Cinco", "Noventa e Seis", "Noventa e Sete", "Noventa e Oito", "Noventa e Nove", "Cem"};

    // Exiba o número por extenso
    printf("Número por extenso: %s\n", nomes[numero]);

    return 0;
}