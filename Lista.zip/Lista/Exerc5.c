#include <stdio.h>

int main() {
    // Declare a variável para armazenar o número
    int numero;

    // Solicite que o usuário insira um número inteiro
    printf("Digite um número inteiro: ");
    scanf("%d", &numero);

    // Calcule o sucessor
    int sucessor = numero + 1;

    // Exiba o sucessor
    printf("O sucessor de %d é: %d\n", numero, sucessor);

    return 0;
}