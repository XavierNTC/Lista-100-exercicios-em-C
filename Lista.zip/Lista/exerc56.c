#include <stdio.h>

// Função para verificar se um número é perfeito
int ehPerfeito(int num) {
    int somaDivisores = 1; // Inclui 1 como divisor próprio

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            somaDivisores += i;

            // Se os divisores são diferentes, adiciona o divisor correspondente
            if (i != num / i) {
                somaDivisores += num / i;
            }
        }
    }

    return somaDivisores == num;
}

int main() {
    int numero;

    printf("Digite um número: ");
    scanf("%d", &numero);

    if (ehPerfeito(numero)) {
        printf("%d é um número perfeito.\n", numero);
    } else {
        printf("%d não é um número perfeito.\n", numero);
    }

    return 0;
}
