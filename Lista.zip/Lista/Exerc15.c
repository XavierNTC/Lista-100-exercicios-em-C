#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar as informações
    float alturaPessoa, sombraPessoa, sombraPredio;

    // Solicite que o usuário insira as informações
    printf("Altura da pessoa (metros): ");
    scanf("%f", &alturaPessoa);

    printf("Sombra da pessoa (metros): ");
    scanf("%f", &sombraPessoa);

    printf("Sombra do prédio (metros): ");
    scanf("%f", &sombraPredio);

    // Calcule a altura do prédio usando a fórmula
    float alturaPredio = (alturaPessoa * sombraPredio) / sombraPessoa;

    // Exiba o resultado
    printf("A altura do prédio é: %.2f metros\n", alturaPredio);

    return 0;
}