#include <stdio.h>

// Função para calcular a soma dos divisores próprios de um número
int somaDivisoresProprios(int num) {
    int soma = 1; // Inclui 1 como divisor próprio

    for (int i = 2; i * i <= num; i++) {
        if (num % i == 0) {
            soma += i;

            // Se os divisores são diferentes, adiciona o divisor correspondente
            if (i != num / i) {
                soma += num / i;
            }
        }
    }

    return soma;
}

// Função para verificar se dois números são amigos
int saoAmigos(int num1, int num2) {
    return (somaDivisoresProprios(num1) == num2) && (somaDivisoresProprios(num2) == num1);
}

int main() {
    int num1, num2;

    printf("Digite o primeiro número: ");
    scanf("%d", &num1);

    printf("Digite o segundo número: ");
    scanf("%d", &num2);

    if (saoAmigos(num1, num2)) {
        printf("%d e %d são números amigos.\n", num1, num2);
    } else {
        printf("%d e %d não são números amigos.\n", num1, num2);
    }

    return 0;
}
