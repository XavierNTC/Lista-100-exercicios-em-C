#include <stdio.h>

int main() {
    int vetor1[10], vetor2[10];

    printf("Digite 10 números para o primeiro vetor:\n");
    for (int i = 0; i < 10; i++) {
        scanf("%d", &vetor1[i]);
    }

    for (int i = 0; i < 10; i++) {
        vetor2[i] = vetor1[i];
    }

    printf("Segundo vetor (cópia do primeiro):\n");
    for (int i = 0; i < 10; i++) {
        printf("%d ", vetor2[i]);
    }
    printf("\n");

    return 0;
}
