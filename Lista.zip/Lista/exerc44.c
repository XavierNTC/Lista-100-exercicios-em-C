#include <stdio.h>

// Função para verificar se um número é primo
int isPrimo(int n) {
    if (n <= 1) {
        return 0; // Não é primo
    }
    for (int i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return 0; // Não é primo
        }
    }
    return 1; // É primo
}

int main() {
    // 44. Imprimir números de 1 até 100 e a soma:
    int soma = 0;
    for (int num = 1; num <= 100; num++) {
        printf("%d\n", num);
        soma += num;
    }
    printf("Soma total: %d\n", soma);

    // 45. Média de 5 números:
    float media, numero, somaMedia = 0;
    for (int i = 0; i < 5; i++) {
        printf("Digite um número: ");
        scanf("%f", &numero);
        somaMedia += numero;
    }
    media = somaMedia / 5;
    printf("Média: %.2f\n", media);

    // 46. Quociente da divisão de A por B:
    int A, B, quociente = 0;
    printf("Digite o valor de A: ");
    scanf("%d", &A);
    printf("Digite o valor de B: ");
    scanf("%d", &B);
    while (A >= B) {
        A -= B;
        quociente++;
    }
    printf("Quociente: %d\n", quociente);

    // 47. Resto da divisão de A por B:
    int resto;
    printf("Digite o valor de A: ");
    scanf("%d", &A);
    printf("Digite o valor de B: ");
    scanf("%d", &B);
    while (A >= B) {
        A -= B;
    }
    resto = A;
    printf("Resto: %d\n", resto);

    // 48. Verificar se um número é primo:
    int num48;
    printf("Digite um número: ");
    scanf("%d", &num48);
    if (isPrimo(num48)) {
        printf("%d é primo.\n", num48);
    } else {
        printf("%d não é primo.\n", num48);
    }

    // 49. Verificar se um número é primo (outra vez):
    int num49;
    printf("Digite um número: ");
    scanf("%d", &num49);
    if (isPrimo(num49)) {
        printf("%d é primo.\n", num49);
    } else {
        printf("%d não é primo.\n", num49);
    }

    return 0;
}