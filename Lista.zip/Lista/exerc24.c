#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os três números
    int num1, num2, num3;

    // Solicite que o usuário insira os três números
    printf("Digite três números separados por espaços: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    // Encontre e exiba o maior entre os três números
    int maior = num1;
    if (num2 > maior) {
        maior = num2;
    }
    if (num3 > maior) {
        maior = num3;
    }

    printf("O maior número é: %d\n", maior);

    return 0;
}