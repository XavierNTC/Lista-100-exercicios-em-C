#include <stdio.h>

int main() {
    int pluviometria[30];

    printf("Digite os índices pluviométricos dos 30 dias do mês de junho:\n");
    for (int i = 0; i < 30; i++) {
        scanf("%d", &pluviometria[i]);
    }

    int somaPrimeiraQuinzena = 0, somaSegundaQuinzena = 0;

    for (int i = 0; i < 15; i++) {
        somaPrimeiraQuinzena += pluviometria[i];
    }

    for (int i = 15; i < 30; i++) {
        somaSegundaQuinzena += pluviometria[i];
    }

    int diaMaisChuvoso = 1, diaMenosChuvoso = 1;

    for (int i = 1; i < 30; i++) {
        if (pluviometria[i] > pluviometria[diaMaisChuvoso - 1]) {
            diaMaisChuvoso = i + 1;
        }
        if (pluviometria[i] < pluviometria[diaMenosChuvoso - 1]) {
            diaMenosChuvoso = i + 1;
        }
    }

    double mediaPrimeiraQuinzena = somaPrimeiraQuinzena / 15.0;
    double mediaSegundaQuinzena = somaSegundaQuinzena / 15.0;

    printf("Dia mais chuvoso: %d\n", diaMaisChuvoso);
    printf("Dia menos chuvoso: %d\n", diaMenosChuvoso);
    printf("Média pluviométrica da primeira quinzena: %.2f\n", mediaPrimeiraQuinzena);
    printf("Média pluviométrica da segunda quinzena: %.2f\n", mediaSegundaQuinzena);

    return 0;
}
