#include <stdio.h>

int main() {
    // Declare a variável para armazenar o caractere
    char caractere;

    // Solicite que o usuário insira o caractere
    printf("Digite um caractere: ");
    scanf(" %c", &caractere);

    // Verifique se o caractere é vogal, consoante, número ou símbolo
    if ((caractere >= 'a' && caractere <= 'z') || (caractere >= 'A' && caractere <= 'Z')) {
        // Verifique se o caractere é uma letra (vogal ou consoante)
        if (caractere == 'a' || caractere == 'e' || caractere == 'i' || caractere == 'o' || caractere == 'u' ||
            caractere == 'A' || caractere == 'E' || caractere == 'I' || caractere == 'O' || caractere == 'U') {
            printf("O caractere é uma vogal.\n");
        } else {
            printf("O caractere é uma consoante.\n");
        }
    } else if (caractere >= '0' && caractere <= '9') {
        // Verifique se o caractere é um número
        printf("O caractere é um número.\n");
    } else {
        // O caractere é um símbolo ou outro tipo de caractere
        printf("O caractere é um símbolo ou outro tipo de caractere.\n");
    }

    return 0;
}