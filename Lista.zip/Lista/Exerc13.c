#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar os valores das resistências
    float R1, R2, R3;

    // Solicite que o usuário insira os valores das resistências
    printf("Digite o valor da resistência R1: ");
    scanf("%f", &R1);

    printf("Digite o valor da resistência R2: ");
    scanf("%f", &R2);

    printf("Digite o valor da resistência R3: ");
    scanf("%f", &R3);

    // Calcule a resistência equivalente em paralelo
    float R_paralelo = 1 / ((1 / R1) + (1 / R2));

    // Calcule a resistência equivalente total
    float R_eq = R_paralelo + R3;

    // Exiba o resultado
    printf("A resistência equivalente do circuito é: %.2f ohms\n", R_eq);

    return 0;
}