#include <stdio.h>

int main() {
    // Declare as variáveis para armazenar o valor da quantia solicitada
    int quantia;

    // Solicite que o usuário insira o valor da quantia solicitada
    printf("Digite o valor da quantia solicitada: R$ ");
    scanf("%d", &quantia);

    // Array para armazenar a quantidade de cada nota disponível
    int notas[] = {100, 50, 20, 10, 5, 2, 1};

    // Calcule e exiba a distribuição ótima das notas
    printf("Distribuição ótima das notas:\n");

    for (int i = 0; i < sizeof(notas) / sizeof(notas[0]); i++) {
        int qtd_notas = quantia / notas[i];
        
        if (qtd_notas > 0) {
            printf("%d nota(s) de R$ %d,00\n", qtd_notas, notas[i]);
            quantia %= notas[i];
        }
    }

    return 0;
}